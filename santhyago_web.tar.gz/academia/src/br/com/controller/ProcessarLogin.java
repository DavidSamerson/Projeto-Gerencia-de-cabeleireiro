package br.com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.com.model.Aluno;
import br.com.model.Professor;

/**
 * Servlet implementation class ProcessarLogin
 */
@WebServlet("/processar")
public class ProcessarLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProcessarLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String susuario = request.getParameter("usuario");
	    String ssenha = request.getParameter("senha");
	    
	    Professor prof = new Professor();
	    prof.setUsuario(susuario);
	    prof.setSenha(ssenha);
	    
	    Aluno aluno = new Aluno();
	    aluno.setUsuario(susuario);
	    aluno.setSenha(ssenha);
	    
	    if ((susuario != null) && (susuario.equals("thaynah7"))){
		      HttpSession sessao = request.getSession();
		      
		      sessao.setAttribute("usuario", prof);
		      request.getRequestDispatcher("indexprofessor.jsp").forward(request, response);
		      
	    }else if ((susuario != null) && (susuario.equals("Maria"))){
	       
		      HttpSession sessao = request.getSession();
		      
		      sessao.setAttribute("usuario", aluno);
		      request.getRequestDispatcher("ficha.jsp").forward(request, response);
		      
	    }else{
		      request.setAttribute("mensagem", "USU�RIO OU SENHA INCORRETO! </br> TENTE NOVAMENTE!");
		      
		      RequestDispatcher saida = request.getRequestDispatcher("login.jsp");
		      saida.forward(request, response);
	    }
	}

}
