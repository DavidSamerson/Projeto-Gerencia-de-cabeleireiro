package br.com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class cadastrarprof
 */
@WebServlet("/cadastrarprof")
public class cadastrarprof extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public cadastrarprof() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			String nome = request.getParameter("nome");
			String rua = request.getParameter("rua");
			String numeroCasa = request.getParameter("numeroCasa");
			String bairro = request.getParameter("bairro");
			String cidade = request.getParameter("cidade");
			String cpf = request.getParameter("cpf");
			String rg = request.getParameter("rg");
			String email = request.getParameter("email");
			String cref = request.getParameter("cref");
			String especialidades = request.getParameter("especialidades");
			String usuario = request.getParameter("usuario");
			String senha = request.getParameter("senha");

			// Alguns valores para teste de recebimento atrav�s do console
			System.out.println("Nome: " + nome);
			System.out.println("Email: " + email);
			System.out.println("CPF: " + cpf);
			System.out.println("cref: " + cref);
			System.out.println("esp: " + especialidades);
			
		    RequestDispatcher rd = request.getRequestDispatcher("cadastroProfessor.jsp");  
		    rd.forward(request, response); 
			
	} catch (Exception e) {
		e.printStackTrace();
	}
}

}