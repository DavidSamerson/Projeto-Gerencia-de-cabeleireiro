package br.com.model;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;

public class User {
	private String usuario;
	private String senha;

	public User() {}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}
}
