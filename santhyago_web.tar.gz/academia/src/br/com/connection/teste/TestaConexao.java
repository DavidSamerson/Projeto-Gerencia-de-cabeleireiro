package br.com.connection.teste;

import java.sql.Connection;
import java.sql.SQLException;

import br.com.connection.ConnectionFactory;

public class TestaConexao {
	  public static void main(String[] args) {
	        try {
	            Connection con = ConnectionFactory.getConnection();
	            System.out.println("Conectado!");
	            con.close();
	            System.out.println("Conexão encerrada com sucesso");

	        } catch (SQLException e) {
	            throw new RuntimeException(e.getMessage());
	        }
	    }
}
