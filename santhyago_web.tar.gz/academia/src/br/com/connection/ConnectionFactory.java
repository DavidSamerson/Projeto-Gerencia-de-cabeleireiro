package br.com.connection;

import java.sql.SQLException;

public class ConnectionFactory {
  public ConnectionFactory() {}
  
  public static java.sql.Connection getConnection() {
    java.sql.Connection con = null;
    try {
   	
    	Class.forName("com.mysql.jdbc.Driver");   
    	con = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/academia", "root", "86801404");
      
      System.out.println("Conectado ao banco com sucesso!");
    } catch (SQLException e) {
      System.out.println("A conex�o falhou... " + e.getMessage());
    }
    catch (ClassNotFoundException e) {
      System.out.println("Erro de Driver... " + e.getMessage());
    }
    
    return con;
  }
}
